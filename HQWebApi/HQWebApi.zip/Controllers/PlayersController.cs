﻿using HQWebApi.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace HQWebApi.Controllers
{
    public class PlayersController : ApiController
    {
        Player[] players = new Player[]
        {
            new Player
            {
                ID = 1,
                Name = "Player1",
                Charisma = 1,
                Intelligence = 10,
                Strength = 20,
                Evil = 3,
                Good = 4
            },
            new Player
            {
                ID = 2,
                Name = "Player2",
                Charisma = 10,
                Intelligence = 100,
                Strength = 200,
                Evil = 30,
                Good = 40
            }
        };

        public IEnumerable<Player> GetAllPlayers()
        {
            return players;
        }

        public IHttpActionResult GetPlayer(int id)
        {
            var player = players.FirstOrDefault((p) => p.ID == id);
            if (player == null)
            {
                return NotFound();
            }
            return Ok(player);
        }
    }
}
